public class Armor
{
	public String m_sName;
	public int m_iDefense;
	public int m_iCost;
	
	public Armor(String name, int defense, int cost)
	{
		m_sName = name;
		m_iDefense = defense;
		m_iCost = cost;
	}
}