import java.awt.*;
import java.util.*;

public class Character extends Sprite
{
	public String m_sName;
	public Weapon m_wWeapon;
	public Armor m_aArmor;
	public HeadGear m_hgHeadgear;
	public Relic m_rRelic;
	
	public int m_iHealth;
	public int m_iMagic;
	
	public int m_iStrength;
	public int m_iDefense;
	
	public int m_iMagicStrength;
	public int m_iMagicDefense;
	
	public int m_iSpeed;
	public int m_iEndurance;
	
	public int m_iLuck;
	public int m_iDetermination;
	
	public int m_iEXP;
	public int m_iMEXP;
	public int m_iWEXP;
	
	public Character(Point Pos, Point Size, Image image, int frame)
	{
		super (Pos, Size, image, frame);
	}
	public Character(){

		}
	
	
	public int GetAttackDmg()
	{
		return m_wWeapon.m_iBaseDamage + m_iStrength + Util.RandomNumber(-2,5);
	}
	
	public int TakeDamage(int amt, char type)
	{
		if (type == 'P')
		{
			if (amt - m_iDefense > 0)
			{
				m_iHealth -= (amt - m_iDefense);
				return (amt-m_iDefense);
			}
		}
		else if (type == 'M')
		{
			if (amt - m_iMagicDefense > 0)
			{
				m_iHealth -= (amt - m_iMagicDefense);
				return (amt-m_iMagicDefense);
			}
		}
		return 0;
	}
	
	public boolean IsLucky()
	{
		int luck = Util.RandomNumber(0,100);
		if (luck < m_iLuck)
			return true;
		return false;
	}
	public boolean IsDetermined()
	{
		int determination = Util.RandomNumber(0,100);
		if (determination < m_iDetermination)
			return true;
		return false;
	}
}