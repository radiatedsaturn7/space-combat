public class Controls
{
	public boolean m_bUp;
	public boolean m_bDown;
	public boolean m_bLeft;
	public boolean m_bRight;
	public boolean m_bA;
	public boolean m_bB;
	public boolean m_bX;
	public boolean m_bY;
	public boolean m_bL;
	public boolean m_bR;
	public boolean m_bStart;
	public boolean m_bSelect;
	
	public boolean m_bRUp;
	public boolean m_bRDown;
	public boolean m_bRLeft;
	public boolean m_bRRight;
	public boolean m_bRA;
	public boolean m_bRB;
	public boolean m_bRX;
	public boolean m_bRY;
	public boolean m_bRL;
	public boolean m_bRR;
	public boolean m_bRStart;
	public boolean m_bRSelect;
	
	public Controls()
	{
	 	m_bUp = false;
	 	m_bDown = false;
	 	m_bLeft = false;
	 	m_bRight = false;
		m_bA = false;
		m_bB = false;
		m_bX = false;
		m_bY = false;
		m_bL = false;
		m_bR = false;
		m_bStart = false;
		m_bSelect = false;
		m_bRUp = false;
	 	m_bRDown = false;
	 	m_bRLeft = false;
	 	m_bRRight = false;
		m_bRA = false;
		m_bRB = false;
		m_bRX = false;
		m_bRY = false;
		m_bRL = false;
		m_bRR = false;
		m_bRStart = false;
		m_bRSelect = false;
	}
	public Controls(Controls c)
	{
	 	m_bUp = c.m_bUp;
	 	m_bDown = c.m_bDown;
	 	m_bLeft = c.m_bLeft;
	 	m_bRight = c.m_bRight;
		m_bA = c.m_bA;
		m_bB = c.m_bB;
		m_bX = c.m_bX;
		m_bY = c.m_bY;
		m_bL = c.m_bL;
		m_bR = c.m_bR;
		m_bStart = c.m_bStart;
		m_bSelect = c.m_bSelect;
		m_bRUp = c.m_bRUp;
	 	m_bRDown = c.m_bRDown;
	 	m_bRLeft = c.m_bRLeft;
	 	m_bRRight = c.m_bRRight;
		m_bRA = c.m_bRA;
		m_bRB = c.m_bRB;
		m_bRX = c.m_bRX;
		m_bRY = c.m_bRY;
		m_bRL = c.m_bRL;
		m_bRR = c.m_bRR;
		m_bRStart = c.m_bRStart;
		m_bRSelect = c.m_bRSelect;
	}
}