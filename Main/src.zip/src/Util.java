import java.util.Random;

public class Util
{
	public static Time m_tTime;
	
	public Util(){}
	
	public static int RandomNumber (int num1, int num2)
	{
		Random r = new Random();
		return (Math.abs(r.nextInt()) % (num2-num1)) + num1;
	}
	
	public static void SetTime(Time t)
	{
		m_tTime = new Time(t);	
	}
}