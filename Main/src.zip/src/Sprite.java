import java.awt.*;
import java.util.*;

public class Sprite
{
	public Image m_iImage;
	public int m_iFrame;//Frame at which we are drawing
	public String m_sName;//Optional naming of sprite, alternative for searching
	protected boolean m_bSetFrame;
	public boolean m_bDonePlaying;
	public boolean m_bIsVisible;
	public int Start, End;
	public int m_iSpriteLoop;
	
	public Point pos;
	public Rectangle m_rcBoundingBox;
	
	public Animation m_aCurrentAnimation;
	public ArrayList m_alAnimations;
	
	public Time m_tLastFrameUpdate;
	
	public Sprite(){};
	
	public Sprite(Sprite s)
	{
		m_rcBoundingBox = new Rectangle(s.m_rcBoundingBox);
		m_iFrame = 0;
		m_bSetFrame = false;
		m_iImage = s.m_iImage;	
		m_sName = s.m_sName;
		m_bIsVisible = s.m_bIsVisible;
		m_tLastFrameUpdate = s.m_tLastFrameUpdate;
		m_bDonePlaying = s.m_bDonePlaying;
	}
	public Sprite(Point Pos, Point Size, Image image, int frame)
	{
		Init(Pos, Size, image, frame);
		m_iFrame = 0;
		m_bSetFrame = false;
	}
	
	public void Init(Point Pos, Point Size, Image image, int frame)
	{
		m_bIsVisible = true;
		pos = new Point(Pos);
		m_rcBoundingBox = new Rectangle (Pos.x, Pos.y, Size.x, Size.y);
		m_iImage = image;	
		m_iFrame = frame;		
		m_tLastFrameUpdate = new Time();
		m_bDonePlaying = false;
	}
	
	public void SetAnimations(ArrayList A)
	{
		m_alAnimations = new ArrayList();
		for (int x = 0; x < A.size(); x++)
		{
			m_alAnimations.add((Animation)(A.get(x)));
		}
	}

	public void SetPosition(Point p)
	{
		pos.x = p.x;
		pos.y = p.y;
	}
	public void SetPosition(int x, int y)
	{
		pos.x = x;
		pos.y = y;
	}
	public void PlayAnimation(String s)
	{
		m_bDonePlaying = false;
		m_iSpriteLoop = 0;
		for (int x = 0; x < m_alAnimations.size(); x++)
		{
			Animation a = (Animation)(m_alAnimations.get(x));
			if (s.equals(a.m_sName))
				m_aCurrentAnimation=new Animation(a);
		}
		if (m_aCurrentAnimation==null)
			m_aCurrentAnimation=new Animation();
		m_iFrame = m_aCurrentAnimation.m_iStartFrame-1;
	//	m_tLastFrameUpdate = new Time();
	}
	public void Reset()
	{
		m_iSpriteLoop = 0;
		m_iFrame = 0;
		m_bSetFrame = false;	

	}

	public void Paint(Graphics g)
	{
		if (!m_bIsVisible)
			return;
			
		Time Temp =new Time(m_tLastFrameUpdate);
		if (m_aCurrentAnimation == null)
		{
			m_aCurrentAnimation = new Animation();
		}
		int i = (int)1000/m_aCurrentAnimation.m_iFPS;
		Temp.AddMilliseconds(i);
		
		System.out.println(Util.m_tTime + " > " + Temp);

		if  (Util.m_tTime.IsGreaterThan(Temp))
		{	
			System.out.println("YES");
			m_tLastFrameUpdate = new Time(Util.m_tTime);
			m_iFrame++;
			if (m_iFrame >= m_aCurrentAnimation.m_iEndFrame && m_aCurrentAnimation.m_bLoop == true)
			{
				m_iFrame = m_aCurrentAnimation.m_iStartFrame;
				m_iSpriteLoop++;
			}
			else if (m_iFrame >= m_aCurrentAnimation.m_iEndFrame)
			{
				m_bDonePlaying = true;
				m_iFrame--;
			}
		}

		g.drawImage(m_iImage, 
		(int)pos.x, 
		(int)pos.y, 
		(int)(pos.x + m_rcBoundingBox.width), 
		(int)(pos.y+m_rcBoundingBox.height),
		
		(int)(1), 
		(int)(1 + (m_rcBoundingBox.height * m_iFrame)  - m_iFrame), 
		(int)(m_rcBoundingBox.x + m_rcBoundingBox.width-1), 
		(int)(m_rcBoundingBox.y) + (int)((m_rcBoundingBox.height * (m_iFrame + 1)) - m_iFrame-2) /* m_iFrame*/,
		
		 null, null);
		 /*
		 System.out.println(
		 	pos.x + " " + 
		 	pos.y + " " + 
		 	((int)(pos.x + m_rcBoundingBox.width)) + " " + 
		 	((int)(pos.y+m_rcBoundingBox.height)));
		 System.out.println(
		 	1 + " " + 
		 	((int)(1 + (m_rcBoundingBox.height * m_iFrame) - m_iFrame)) + " " + 
		 	(m_rcBoundingBox.x + m_rcBoundingBox.width-1) + " " + 
		 	(int)(m_rcBoundingBox.y) + (int)((m_rcBoundingBox.height * (m_iFrame + 1)) - m_iFrame-2) );
	
		 System.out.println();
		 System.out.println();
		 System.out.println();
		 */
	}	
	
	public String getName()
	{
		return m_sName;
	}
}