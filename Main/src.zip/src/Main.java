/* COPYRIGHT 2005 ROB PISKULE
 *ALL RIGHTS RESERVED
 *
 *OPEN SOURCE< LEAVE ALL CREDITS AT TOP!*/



import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.Line2D;
import java.*;


public class Main extends Applet implements Runnable, MouseListener
{
	//DEFINES
	int STARTING = 0;
	int SPLASH = 1;
	int NEWGAME = 2;
	int LOADGAME = 3;
	int OPTIONS = 4;
	int RUNNING = 5;
	int DEMO = 6;
	int END = 7;
	
	//OTHER
	boolean m_bUseButtonToggle = false;
	
	static int m_iPointerSelection = 0;
	
	ArrayList m_alPrintText = new ArrayList();
	ArrayList m_alSprite = new ArrayList();
	
	private Image dbImage;
	private Graphics dbg;
	
	Controls m_cPlayerControls;
	
	Sprite s;
	
	Line2D.Float G_l;
	ArrayList m_alAllEntities = new ArrayList();
	
	public int m_iGameStatus;
	
	
	public void init()
	{
		m_iGameStatus = STARTING;
		m_cPlayerControls = new Controls();
		Time t = new Time(); //time = 0
		Util.SetTime(t); //set global time to 0
	}

	public void start ()
	{
		Thread th = new Thread (this);
		th.start ();
	}

	public void stop()
	{

	}

	public void destroy()
	{

	}

	public void run ()
	{
		Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
		while (true)
		{
			repaint();
			try
			{
				Thread.sleep (17);
				Util.m_tTime.AddMilliseconds(17);
			}
			catch (InterruptedException ex)
			{
			}
			Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public void Starting(Graphics g)
	{
		Animation a = new Animation();
		ArrayList  AnimationList = new ArrayList();
		Sprite s = new Sprite();
		
		
		s = new Sprite(new Point(0,0), new Point(64,48), getImage(getCodeBase(), "Loading.jpg") ,1);
			AnimationList = new ArrayList();
			a = new Animation("PRINT",0,1,true,17);
			AnimationList.add(a);
			s.SetAnimations(AnimationList);
			s.PlayAnimation("PRINT");
		m_alSprite.add(s);
		if (m_cPlayerControls.m_bStart)
		{
			m_alSprite.remove(0);
			m_alPrintText.add(new Text("Start", 140,100));
			m_alPrintText.add(new Text("Load", 140,120));
			m_alPrintText.add(new Text("Options", 140,140));
			m_alSprite = new ArrayList();
			
			s = new Sprite(new Point(0,0), new Point(640,480), getImage(getCodeBase(), "Splash.jpg") ,1);
				AnimationList = new ArrayList();
				a = new Animation("PRINT",0,0,true,17);
				AnimationList.add(a);
				s.SetAnimations(AnimationList);
				s.PlayAnimation("PRINT");
			m_alSprite.add(s);
			s = new Sprite(new Point(0,100),new Point(135,480),getImage(getCodeBase(), "Cursor.jpg"), 1);
				AnimationList = new ArrayList();
				a = new Animation("PRINT",0,0,true,17);
				AnimationList.add(a);
				s.SetAnimations(AnimationList);
				s.PlayAnimation("PRINT");
			m_alSprite.add(s);
			
			m_iGameStatus = SPLASH;
		}
	}
	public void Splash(Graphics g)
	{
		Sprite pointer = ((Sprite)(m_alSprite.get(1)));
		if (m_cPlayerControls.m_bDown)
		{
			if (pointer.pos.y < 130)
			pointer.pos.y++;
		}
		else if (m_cPlayerControls.m_bUp)
		{
			if (pointer.m_rcBoundingBox.y > 90)
			pointer.pos.y--;
		}
			
		if (pointer.pos.y < 105)
		{
			Text temp1; 
			Text temp2; 
			Text temp3;
			temp1 = new Text((Text)m_alPrintText.get(0));
			temp2 = new Text((Text)m_alPrintText.get(1));
			temp3 = new Text((Text)m_alPrintText.get(2));
			m_alPrintText = null;
			m_alPrintText = new ArrayList();
			temp1.m_cColor = Color.yellow;
			temp2.m_cColor = Color.black;
			temp3.m_cColor = Color.black;
			m_alPrintText.add(temp1);
			m_alPrintText.add(temp2);
			m_alPrintText.add(temp3);
			if (m_cPlayerControls.m_bStart)
			{
				m_alPrintText = new ArrayList();
				m_alSprite = new ArrayList();
				m_iGameStatus = NEWGAME;
			}
		}
		else if (pointer.pos.y >= 105 && pointer.pos.y < 120)
		{
			Text temp1, temp2, temp3;
			temp1 = new Text(((Text)(m_alPrintText.get(0))));
			temp2 = new Text(((Text)(m_alPrintText.get(1))));
			temp3 = new Text(((Text)(m_alPrintText.get(2))));
			m_alPrintText = null;
			m_alPrintText = new ArrayList();
			temp1.m_cColor = Color.black;
			temp2.m_cColor = Color.yellow;
			temp3.m_cColor = Color.black;
			m_alPrintText.add(temp1);
			m_alPrintText.add(temp2);
			m_alPrintText.add(temp3);
			if (m_cPlayerControls.m_bStart)
			{
				m_alPrintText = new ArrayList();
				m_alSprite = new ArrayList();
				m_iGameStatus = LOADGAME;
			}
		}
		else if (pointer.pos.y >= 120)
		{
			Text temp1, temp2, temp3;
			temp1 = new Text(((Text)(m_alPrintText.get(0))));
			temp2 = new Text(((Text)(m_alPrintText.get(1))));
			temp3 = new Text(((Text)(m_alPrintText.get(2))));
			m_alPrintText = null;
			m_alPrintText = new ArrayList();
			temp1.m_cColor = Color.black;
			temp2.m_cColor = Color.black;
			temp3.m_cColor = Color.yellow;
			m_alPrintText.add(temp1);
			m_alPrintText.add(temp2);
			m_alPrintText.add(temp3);	
			if (m_cPlayerControls.m_bStart)
			{
				m_alPrintText = new ArrayList();
				m_alSprite = new ArrayList();
				m_iGameStatus = OPTIONS;
			}
		}
	}
	public void Newgame(Graphics g)
	{
		ArrayList AnimationList = new ArrayList();
		Animation a=new Animation();
		if (m_cPlayerControls.m_bStart)
		{
			m_alPrintText = new ArrayList();
			m_alSprite = new ArrayList();
			
			Character s = new Character(new Point(0,0), new Point(154,304), getImage(getCodeBase(), "CHAR.gif") ,1);
				AnimationList = new ArrayList();
				a = new Animation("WALK_LEFT",7,8,false,3);
				AnimationList.add(a);
				a = new Animation("WALK_RIGHT",4,5,false,3);
				AnimationList.add(a);
				a = new Animation("WALK_UP",10,11,false,3);
				AnimationList.add(a);
				a = new Animation("WALK_DOWN",1,2,false,3);
				AnimationList.add(a);
				a = new Animation("IDLE",1,1,false,1);
				AnimationList.add(a);
				s.SetAnimations(AnimationList);
				s.PlayAnimation("WALK_LEFT");
			m_alSprite.add(s);
			m_iGameStatus = RUNNING;
		}
	}
	public void Loadgame(Graphics g)
	{
		System.out.println("LOAD");
		m_alPrintText = new ArrayList();
		m_alSprite = new ArrayList();
		m_iGameStatus = RUNNING;
	}
	public void Options(Graphics g)
	{
		System.out.println("OPTIONS");
	}
	public void Run(Graphics g)
	{
//		System.out.println("RUNNING");
		if (m_cPlayerControls.m_bStart)
			m_iGameStatus = RUNNING;
			
			Sprite S = new Sprite();
		if (m_alSprite.size() > 0)
			S = (Sprite)m_alSprite.get(0);
			
			if (m_cPlayerControls.m_bUp)
			{
				if (S.m_bDonePlaying || !S.m_aCurrentAnimation.m_sName.equals("WALK_UP"))
				S.PlayAnimation("WALK_UP");
				S.pos.y-=1;
			}
			if (m_cPlayerControls.m_bDown)
			{
				if (S.m_bDonePlaying || !S.m_aCurrentAnimation.m_sName.equals("WALK_DOWN"))
				S.PlayAnimation("WALK_DOWN");
				S.pos.y+=1;
			}
			if (m_cPlayerControls.m_bLeft)
			{
				if (S.m_bDonePlaying || !S.m_aCurrentAnimation.m_sName.equals("WALK_LEFT"))
				S.PlayAnimation("WALK_LEFT");
				S.pos.x-=1;
			}
			if (m_cPlayerControls.m_bRight)
			{
				if (S.m_bDonePlaying || !S.m_aCurrentAnimation.m_sName.equals("WALK_RIGHT"))
				S.PlayAnimation("WALK_RIGHT");
				S.pos.x+=1;
			}
			if (!m_cPlayerControls.m_bUp && !m_cPlayerControls.m_bDown &&
			!m_cPlayerControls.m_bLeft && !m_cPlayerControls.m_bRight && S.m_bDonePlaying)
			{
				S.PlayAnimation("IDLE");
			}
				
			
		
	}
	public void Demo(Graphics g)
	{		
	}
	public void End(Graphics g)
	{
	}











	public void Collision()
	{

	}
	
	public void update (Graphics g)
	{
		//check collision
		Collision();
			if (m_iGameStatus == STARTING)
				Starting(g);
			else if (m_iGameStatus == SPLASH)
				Splash(g);
			else if (m_iGameStatus == NEWGAME)
				Newgame(g);
			else if (m_iGameStatus == LOADGAME)
				Loadgame(g);
			else if (m_iGameStatus == OPTIONS)
				Options(g);
			else if (m_iGameStatus == RUNNING)
				Run(g);
			else if (m_iGameStatus == DEMO)
				Demo(g);
			else if (m_iGameStatus == END)
				End(g);
				
		if (Util.m_tTime.m_iMilliseconds % 2 != 0) //temp frame rate
			return;
		
		if (dbImage == null)
		{
			dbImage = createImage (this.getSize().width, this.getSize().height);
			dbg = dbImage.getGraphics ();
		}

		dbg.setColor (getBackground ());
		dbg.fillRect (0, 0, this.getSize().width, this.getSize().height);

		dbg.setColor (getForeground());
		paint (dbg);

		g.drawImage (dbImage, 0, 0, this);
	}
    
	public boolean keyDown(Event e, int key)
  	{  			
	  	if(key == Event.UP && (!m_bUseButtonToggle || m_bUseButtonToggle && !m_cPlayerControls.m_bRUp))
	  	{
		    m_cPlayerControls.m_bUp = true;
		    m_cPlayerControls.m_bRUp = true;
		}
		else if (m_bUseButtonToggle && m_cPlayerControls.m_bRUp)
		{
			m_cPlayerControls.m_bUp = false;
		}
		if(key == Event.DOWN && (!m_bUseButtonToggle || m_bUseButtonToggle && !m_cPlayerControls.m_bRDown))
		{	
			m_cPlayerControls.m_bDown = true;
			m_cPlayerControls.m_bRDown = true;
		}
		else if (m_bUseButtonToggle && m_cPlayerControls.m_bRDown)
		{
			m_cPlayerControls.m_bDown = false;
		}
		if(key == Event.LEFT && (!m_bUseButtonToggle || m_bUseButtonToggle && !m_cPlayerControls.m_bRLeft))
		{	
			m_cPlayerControls.m_bLeft = true;
		 	m_cPlayerControls.m_bRLeft = true;
		}
		else if (m_bUseButtonToggle && m_cPlayerControls.m_bRLeft)
		{
			m_cPlayerControls.m_bLeft = false;
		}
		if(key == Event.RIGHT && (!m_bUseButtonToggle || m_bUseButtonToggle && !m_cPlayerControls.m_bRRight))
		{	
			m_cPlayerControls.m_bRight = true;
		 	m_cPlayerControls.m_bRRight = true;
		}
		else if (m_bUseButtonToggle && m_cPlayerControls.m_bRStart)
		{
			m_cPlayerControls.m_bRight = false;
		}
		if(key == Event.ENTER && (!m_bUseButtonToggle || m_bUseButtonToggle && !m_cPlayerControls.m_bRStart))
	 	{	
	 		m_cPlayerControls.m_bStart = true; 	
	 		m_cPlayerControls.m_bRStart = true;
	 	}	
	 	else if (m_bUseButtonToggle && m_cPlayerControls.m_bRStart)
		{
			m_cPlayerControls.m_bStart = false;
		}
	  	return false;
	  	
  	}
  	
  	public boolean keyUp(Event e, int key)
  	{ 

	  	if(key == Event.UP)
	  	{	
	  		m_cPlayerControls.m_bUp = false;
	  		m_cPlayerControls.m_bRUp = false;
	  	}
	  	if(key == Event.DOWN)
	  	{	
	  		m_cPlayerControls.m_bDown = false;
	  		m_cPlayerControls.m_bRDown = false;
	  	}
	  	if(key == Event.LEFT)
	  	{	
	  		m_cPlayerControls.m_bLeft = false;
	  		m_cPlayerControls.m_bRLeft = false;
	  	}
	  	if(key == Event.RIGHT)
	  	{
	  		m_cPlayerControls.m_bRight = false;
	  		m_cPlayerControls.m_bRRight = false;
	  	}
	  	if(key == Event.ENTER)
		{ 	
		 	m_cPlayerControls.m_bStart = false;  
			m_cPlayerControls.m_bRStart = false;
		}
  		return true;
  		
  	} 
	
	public void paint (Graphics g)
	{
		/*
		if (FPSthingy > 1)
		{
			FPSthingy = 0;
		}
		else
			return;
			*/
		/*
		if (s != null)
		{
			s.Paint(g);
		}
		*/
	//	System.out.println(m_alSprite.size());
		for (int x = 0; x < m_alSprite.size(); x++)
		{
			((Sprite)(m_alSprite.get(x))).Paint(g);
		}
		for (int x = 0; x < m_alPrintText.size(); x++)
		{
			((Text)(m_alPrintText.get(x))).Paint(g);
		}
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e)  {} 
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e){}
}