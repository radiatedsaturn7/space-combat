### ##  ###                 #   #       #####            #               
 #   ##  #                      #        #   #                           
 #   ### # ### ###  #####  ##  ### ##  # #   #  ##  ### ##   #### #####  
 #   # ### ### ###   #  #   #   #   # ## #   # #### ###  #  #  #   #  #  
 #   #  ## ### # #   #  #   #   #   # #  #   # #    ###  #  ####   #  #  
### ###  # ### ## # ###### ###  ##   ## #####   ### ### ### ##### ###### 
------------------------------------ # -------------------- #   # ------    
                                    #                       ####   

This is a port of the http://nehe.gamedev.net OpenGL tutorials to the 
Android 1.5 OpenGL ES platform. Thanks to NeHe and all contributors for 
their great tutorials and great documentation. This source should be 
used together with the explanations made at http://nehe.gamedev.net.
The code is based on the original Visual C++ code including comments. 
It has been altered and extended to meet the Android requirements. 
The Java code has according comments.

If you use this code or find it helpful, please visit and send a shout 
to the author under http://www.insanitydesign.com/

DISCLAIMER
This source and the whole package comes without warranty. It may or may 
not harm your computer or cell phone. Please use with care. Any damage 
cannot be related back to the author. The source has been tested on a 
virtual environment and scanned for viruses and has passed all tests.

              =       :         Savas Ziplies (nea) / INsanityDesign.com                
               ..III..                 
              IIIIIIIII.               
            .II IIIII II.              
            IIIIIIIIIIIII              
         II ............. II           
        III.IIIIIIIIIIIII.III          
        III.IIIIIIIIIIIII.III          
        III.IIIIIIIIIIIII.III          
        III.IIIIIIIIIIIII.III          
         II IIIIIIIIIIIII II+          
            IIIIIIIIIIIII              
             IIIIIIIIIII               
              .III :II.                
              .III :II.                
               .:   ..                 